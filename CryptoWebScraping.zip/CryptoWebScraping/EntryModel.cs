﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebScraping1
{
    public class EntryModel
    {
        public string Title { get; set; }
        public string Price { get; set; }
        public string Change { get; set; }
    }
}
