﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Text;
using System.Web;

namespace WebScraping1
{
    class Scraper
    {
        private ObservableCollection<EntryModel> _entries = new ObservableCollection<EntryModel>();



        public ObservableCollection<EntryModel> Entries
        {
            get { return _entries; }
            set { _entries = value; }
        }

        public void ScrapeData(string page)
        {
            var web = new HtmlWeb();
            var doc = web.Load(page);


            var Articles = doc.DocumentNode.SelectNodes("//*[@class = '_2mHoLKk1EmQ90Hj2VxwVKC _2cEwIPLxNCKyZSBxk7MyUQ Q0Cxwokka8qzW-qAyjdq6 pointer']");

            foreach (var article in Articles)
            {
                var header = HttpUtility.HtmlDecode(article.SelectSingleNode(".//div[@class = 'text-left truncate _1hazOxgsUXq0rb-UgDZwNp _1GdBC6rgsSADLryaaGeEuX w8u1-Ks6zzfWwPQ23ywUj _36FIyjphKz71izCg1N-Uks']").InnerText);
                var price = HttpUtility.HtmlDecode(article.SelectSingleNode(".//div[@class = 'text-right _1hazOxgsUXq0rb-UgDZwNp LNc8C7U5Q_4hVq8G7HQHa _36FIyjphKz71izCg1N-Uks overflow-visible']").InnerText);
                var change = HttpUtility.HtmlDecode(article.SelectSingleNode(".//div[@class = 'text-right _1hazOxgsUXq0rb-UgDZwNp _2FulmH3iQ5Kp8yQh0HAxic _36FIyjphKz71izCg1N-Uks']").InnerText);

                if (header == "Bitcoin" || header == "Ethereum" || header == "Solana" || header == "Litecoin" || header == "Chainlink")
                {
                    _entries.Add(new EntryModel { Title = header, Price = price, Change = change });
                }
            }
        }
    }
}
